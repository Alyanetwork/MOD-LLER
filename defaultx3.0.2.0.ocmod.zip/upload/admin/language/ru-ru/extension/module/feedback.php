<?php
// Heading
$_['heading_title']       = 'Блок с обратной связью';

// Text
$_['text_extension']      = 'Расширения';
$_['text_success']        = 'Настройки успешно изменены!';
$_['text_edit']           = 'Настройки модуля';

// Entry
$_['entry_heading_title'] = 'Введите заголовок';
$_['entry_text_main']     = 'Введите описание';
$_['entry_email_status']  = 'Запрашивать e-mail';
$_['entry_header_status'] = 'Кнопка в Header';
$_['entry_status']        = 'Статус';

// Error
$_['error_permission']    = 'У Вас нет прав для управления данным модулем!';