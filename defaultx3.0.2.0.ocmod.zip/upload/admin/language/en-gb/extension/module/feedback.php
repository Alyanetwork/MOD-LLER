<?php
// Heading
$_['heading_title']    = 'Block with feedback';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified block with feedback!';
$_['text_edit']        = 'Edit block with feedback module';

// Entry
$_['entry_heading_title'] = 'Enter title';
$_['entry_text_main']     = 'Enter description';
$_['entry_email_status']  = 'Request an e-mail';
$_['entry_header_status'] = 'Button in header';
$_['entry_status']        = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify block with feedback module!';