<?php
// Heading
$_['heading_title']			= 'Quick Mail';

// Text
$_['text_extension']		= 'Extensions';
$_['text_success']			= 'Success: You have modified dashboard Quick Mail!';
$_['text_edit']				= 'Edit Dashboard Quick Mail';
$_['text_success']			= 'Your message has been successfully sent!';

// Entry
$_['entry_status']			= 'Status';
$_['entry_sort_order']		= 'Sort Order';
$_['entry_width']			= 'Width';
$_['entry_email']			= 'Email Address';
$_['entry_subject']			= 'Subject';
$_['entry_message']			= 'Message';

// Button
$_['button_send']			= 'Send Email';

// Error
$_['error_permission']		= 'Warning: You do not have permission to modify dashboard Quick Mail!';
$_['error_email']			= 'E-Mail Address does not appear to be valid!';
$_['error_subject']			= 'Subject required!';
$_['error_message']			= 'Message required!';