<?php
// Heading
$_['heading_title']			= 'Calendar Event';

// Text
$_['text_extension']		= 'Extensions';
$_['text_success']			= 'Success: You have modified dashboard calendar event!';
$_['text_edit']				= 'Edit Dashboard Calendar Event';
$_['text_view']				= 'View more...';
$_['text_default']			= 'Default';
$_['text_event_list']		= 'Event List';
$_['text_demo_event_h1']	= 'Meeting to client';
$_['text_demo_event_h2']	= 'Pick up your mom';
$_['text_demo_event_p1']	= 'Hey, you have a meeting with the client on';
$_['text_demo_event_p2']	= 'Don\'t forget to pick up your mom at the airport';
$_['text_demo_event']		= '<div class="alert alert-info"><b>Info!</b> This is just a demo, you are currently using a calendar demo, if you need it click <a class="text-info" href="https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=34792" target="_blank"><b>here</b></a>.</div>';

// Entry
$_['entry_status']			= 'Status';
$_['entry_sort_order']		= 'Sort Order';
$_['entry_width']			= 'Width';

// Error
$_['error_permission']		= 'Warning: You do not have permission to modify dashboard Calendar Event!';