/**
 * Base5Builder - Start
 */


/* Get URL Parameters */
var getUrlParameter = function getUrlParameter(sParam) {
	var sPageURL = decodeURIComponent(window.location.search.substring(1)),
	sURLVariables = sPageURL.split('&'),
	sParameterName,
	i;

	for (i = 0; i < sURLVariables.length; i++) {
		sParameterName = sURLVariables[i].split('=');

		if (sParameterName[0] === sParam) {
			return sParameterName[1] === undefined ? true : sParameterName[1];
		}
	}
};

// Token
var token = getUrlParameter('token');
var route = getUrlParameter('route');

 $(document).ready(function(){

 	/* Submit Forms */
 	$('button[type=\'submit\']').on('click', function() {
		$("form[id*='form-']").submit();
	});
 	
 	/* Menu - Active */
 	$('#menu > li').each(function(){
 		var topParentListItem = $(this);
 		var topParentListItemID = topParentListItem.attr('id');

 		topParentListItem.find('a').each(function(){
 			if(typeof $(this).attr('href') != 'undefined'){
 				var itemLink = $(this).attr('href');
 				var itemLinkSplit1 = itemLink.split('?');
 				var itemLinkSplit2 = itemLinkSplit1[1].split('&');

 				var itemLinkRoute = itemLinkSplit2[0].substring(6);

 				if(route == itemLinkRoute){
 					topParentListItem.addClass('active');
 				}

 			}
 		});
 	});

 	/* Flot */
 	if($('#chart-sale').length){
	 	$('#range a').on('click', function(e) {
	 		e.preventDefault();

	 		$(this).parent().parent().find('li').removeClass('active');

	 		$(this).parent().addClass('active');

	 		$.ajax({
	 			type: 'get',
	 			url: 'index.php?route=dashboard/chart/chart&token=' + token + '&range=' + $(this).attr('href'),
	 			dataType: 'json',
	 			success: function(json) {
	 				if(typeof json['order'] == 'undefined'){
	 					return false;
	 				}

	 				var option = {	
						series: {
							lines: { 
								show: true,
								fill: true
							},
							points: {
								show: true
							},
							shadowSize: 0	
						},
						grid: {
							verticalLines: true,
							hoverable: true,
							clickable: true,
							tickColor: "#d5d5d5",
							borderWidth: 1,
							color: '#fff'
						},
						colors: ["rgba(38, 185, 154, 0.38)", "rgba(3, 88, 106, 0.38)"],
						legend: {
							show: true
						},
						xaxis: {
							ticks: json.xaxis
						},
						tooltip: true,
						tooltipOpts: {
							content: "'%s': <b>%y</b>",
							shifts: {
								x: -60,
								y: 25
							}
						}
					}

					$.plot($('#chart-sale'), [json.order, json.customer], option);
	 				

	 			},
	 			error: function(xhr, ajaxOptions, thrownError) {
	 				alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
	 			}
	 		});
	 	});

	 	$('#range .active a').trigger('click');
 	}

 	/* Map */
 	if($('#vmap').length){
		$.ajax({
			url: 'index.php?route=dashboard/map/map&token=' + token,
			dataType: 'json',
			success: function(json) {
				data = [];
							
				for (i in json) {
					data[i] = json[i]['total'];
				}

				var labelOrders = $('#vmap').data('label-orders');
				var labelSales = $('#vmap').data('label-sales');
						
				$('#vmap').vectorMap({
					map: 'world_en',
					backgroundColor: '#FFFFFF',
					borderColor: '#FFFFFF',
					color: 'rgba(38, 185, 154, 0.38)',
					hoverOpacity: 0.7,
					selectedColor: '#666666',
					enableZoom: true,
					showTooltip: true,
					scaleColors: ['#b6d6ff', '#337AB7'],
					values: data,
					normalizeFunction: 'polynomial',
					onLabelShow: function(event, label, code) {

						if (json[code]) {
							label.html('<strong>' + label.text() + '</strong><br />' + labelOrders + ': ' + json[code]['total'] + '<br />' + labelSales + ': '+ json[code]['amount']);
						}else{
							label.html('<strong>' + label.text() + '</strong>');
						}
					}
				});			
			},
	        error: function(xhr, ajaxOptions, thrownError) {
	            alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
	        }
		});
 	}

 	/* Sidebar - Donut */
 	if($('#stats-canvas').length){

 		var entryLabel1 = $('#stats-canvas').closest('#stats').attr('data-entry-1-label');
 		var entryValue1 = $('#stats-canvas').closest('#stats').attr('data-entry-1-value');

 		var entryLabel2 = $('#stats-canvas').closest('#stats').attr('data-entry-2-label');
 		var entryValue2 = $('#stats-canvas').closest('#stats').attr('data-entry-2-value');

 		var entryLabel3 = $('#stats-canvas').closest('#stats').attr('data-entry-3-label');
 		var entryValue3 = $('#stats-canvas').closest('#stats').attr('data-entry-3-value');

	 	var options = {
	 		legend: false,
	 		responsive: false
	 	};

	 	new Chart(document.getElementById("stats-canvas"), {
	 		type: 'doughnut',
	 		tooltipFillColor: "rgba(51, 51, 51, 0.55)",
	 		data: {
	 			labels: [
	 			entryLabel1 + '\n(%)',
	 			entryLabel2 + '\n(%)',
	 			entryLabel3 + '\n(%)'
	 			],
	 			datasets: [{
	 				data: [entryValue1, entryValue2, entryValue3],
	 				backgroundColor: [
	 				"#26B99A",
	 				"#F4852F",
	 				"#3498DB"
	 				],
	 				hoverBackgroundColor: [
	 				"#66DFC6",
	 				"#F9BE90",
	 				"#8BC4EA"
	 				],
	 				borderWidth: 2
	 			}]
	 		},
	 		options: options
	 	});
 	}
 });

/**
 * Copied from default OpenCart js file
 */

// Autocomplete
(function($) {
	$.fn.autocomplete = function(option) {
		return this.each(function() {
			this.timer = null;
			this.items = new Array();

			$.extend(this, option);

			$(this).attr('autocomplete', 'off');

			// Focus
			$(this).on('focus', function() {
				this.request();
			});

			// Blur
			$(this).on('blur', function() {
				setTimeout(function(object) {
					object.hide();
				}, 200, this);
			});

			// Keydown
			$(this).on('keydown', function(event) {
				switch(event.keyCode) {
					case 27: // escape
						this.hide();
						break;
					default:
						this.request();
						break;
				}
			});

			// Click
			this.click = function(event) {
				event.preventDefault();

				value = $(event.target).parent().attr('data-value');

				if (value && this.items[value]) {
					this.select(this.items[value]);
				}
			}

			// Show
			this.show = function() {
				var pos = $(this).position();

				$(this).siblings('ul.dropdown-menu').css({
					top: pos.top + $(this).outerHeight(),
					left: pos.left
				});

				$(this).siblings('ul.dropdown-menu').show();
			}

			// Hide
			this.hide = function() {
				$(this).siblings('ul.dropdown-menu').hide();
			}

			// Request
			this.request = function() {
				clearTimeout(this.timer);

				this.timer = setTimeout(function(object) {
					object.source($(object).val(), $.proxy(object.response, object));
				}, 200, this);
			}

			// Response
			this.response = function(json) {
				html = '';

				if (json.length) {
					for (i = 0; i < json.length; i++) {
						this.items[json[i]['value']] = json[i];
					}

					for (i = 0; i < json.length; i++) {
						if (!json[i]['category']) {
							html += '<li data-value="' + json[i]['value'] + '"><a href="#">' + json[i]['label'] + '</a></li>';
						}
					}

					// Get all the ones with a categories
					var category = new Array();

					for (i = 0; i < json.length; i++) {
						if (json[i]['category']) {
							if (!category[json[i]['category']]) {
								category[json[i]['category']] = new Array();
								category[json[i]['category']]['name'] = json[i]['category'];
								category[json[i]['category']]['item'] = new Array();
							}

							category[json[i]['category']]['item'].push(json[i]);
						}
					}

					for (i in category) {
						html += '<li class="dropdown-header">' + category[i]['name'] + '</li>';

						for (j = 0; j < category[i]['item'].length; j++) {
							html += '<li data-value="' + category[i]['item'][j]['value'] + '"><a href="#">&nbsp;&nbsp;&nbsp;' + category[i]['item'][j]['label'] + '</a></li>';
						}
					}
				}

				if (html) {
					this.show();
				} else {
					this.hide();
				}

				$(this).siblings('ul.dropdown-menu').html(html);
			}

			$(this).after('<ul class="dropdown-menu"></ul>');
			$(this).siblings('ul.dropdown-menu').delegate('a', 'click', $.proxy(this.click, this));

		});
	}
})(window.jQuery);


$(document).ready(function() {
	// Tooltip remove fixed
	$(document).delegate('[data-toggle=\'tooltip\']', 'click', function(e) {
		$('body > .tooltip').remove();
	});

	// Override summernotes image manager
	$('.summernote').each(function() {
		var element = this;
		
		$(element).summernote({
			disableDragAndDrop: true,
			height: 300,
			toolbar: [
				['style', ['style']],
				['font', ['bold', 'underline', 'clear']],
				['fontname', ['fontname']],
				['color', ['color']],
				['para', ['ul', 'ol', 'paragraph']],
				['table', ['table']],
				['insert', ['link', 'image', 'video']],
				['view', ['fullscreen', 'codeview', 'help']]
			],
			buttons: {
    			image: function() {
					var ui = $.summernote.ui;

					// create button
					var button = ui.button({
						contents: '<i class="fa fa-image" />',
						tooltip: $.summernote.lang[$.summernote.options.lang].image.image,
						click: function () {
							$('#modal-image').remove();
						
							$.ajax({
								url: 'index.php?route=common/filemanager&token=' + getURLVar('token'),
								dataType: 'html',
								beforeSend: function() {
									$('#button-image i').replaceWith('<i class="fa fa-circle-o-notch fa-spin"></i>');
									$('#button-image').prop('disabled', true);
								},
								complete: function() {
									$('#button-image i').replaceWith('<i class="fa fa-upload"></i>');
									$('#button-image').prop('disabled', false);
								},
								success: function(html) {
									$('body').append('<div id="modal-image" class="modal">' + html + '</div>');
									
									$('#modal-image').modal('show');
									
									$('#modal-image a.thumbnail').on('click', function(e) {
										e.preventDefault();
										
										$(element).summernote('insertImage', $(this).attr('href'));
																	
										$('#modal-image').modal('hide');
									});
								}
							});						
						}
					});
				
					return button.render();
				}
  			}
		});
	});

	// Image Manager
	$(document).delegate('a[data-toggle=\'image\']', 'click', function(e) {
		e.preventDefault();

		$('.popover').popover('hide', function() {
			$('.popover').remove();
		});

		var element = this;

		$(element).popover({
			html: true,
			placement: 'right',
			trigger: 'manual',
			content: function() {
				return '<button type="button" id="button-image" class="btn btn-primary"><i class="fa fa-pencil"></i></button> <button type="button" id="button-clear" class="btn btn-danger"><i class="fa fa-trash-o"></i></button>';
			}
		});

		$(element).popover('show');

		$('#button-image').on('click', function() {
			$('#modal-image').remove();

			$.ajax({
				url: 'index.php?route=common/filemanager&token=' + getURLVar('token') + '&target=' + $(element).parent().find('input').attr('id') + '&thumb=' + $(element).attr('id'),
				dataType: 'html',
				beforeSend: function() {
					$('#button-image i').replaceWith('<i class="fa fa-circle-o-notch fa-spin"></i>');
					$('#button-image').prop('disabled', true);
				},
				complete: function() {
					$('#button-image i').replaceWith('<i class="fa fa-pencil"></i>');
					$('#button-image').prop('disabled', false);
				},
				success: function(html) {
					$('body').append('<div id="modal-image" class="modal">' + html + '</div>');

					$('#modal-image').modal('show');
				}
			});

			$(element).popover('hide', function() {
				$('.popover').remove();
			});
		});

		$('#button-clear').on('click', function() {
			$(element).find('img').attr('src', $(element).find('img').attr('data-placeholder'));

			$(element).parent().find('input').attr('value', '');

			$(element).popover('hide', function() {
				$('.popover').remove();
			});
		});
	});

	// tooltips on hover
	$('[data-toggle=\'tooltip\']').tooltip({container: 'body', html: true});

	// Makes tooltips work on ajax generated content
	$(document).ajaxStop(function() {
		$('[data-toggle=\'tooltip\']').tooltip({container: 'body'});
	});

	// https://github.com/opencart/opencart/issues/2595
	$.event.special.remove = {
		remove: function(o) {
			if (o.handler) {
				o.handler.apply(this, arguments);
			}
		}
	}

	$('[data-toggle=\'tooltip\']').on('remove', function() {
		$(this).tooltip('destroy');
	});
});