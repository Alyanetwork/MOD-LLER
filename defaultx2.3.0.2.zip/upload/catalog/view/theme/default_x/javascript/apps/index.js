function init() {
    header();
    productLayout();
}