/* Equal height product-thumb */
function getEqualHeightProductThumb() {
    $('.product-thumb .caption').equalHeight();
}

function productLayout() {
    getEqualHeightProductThumb();
}